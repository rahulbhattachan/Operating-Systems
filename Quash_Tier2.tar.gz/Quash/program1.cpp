// program1.cpp
#include <iostream>
#include <unistd.h>

int main() {
    /*std::cout << "Running program1..." << std::endl;*/
    sleep(2);  // Sleep for 2 seconds to simulate some processing
    /*std::cout << "Exiting program1..." << std::endl;*/
    return 0;
}

