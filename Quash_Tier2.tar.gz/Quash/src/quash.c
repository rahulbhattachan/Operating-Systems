   // Check if loop is running
        bool is_running() {
          return state.running;
          state.running = false;
          while (is_running()) {
          
          this project is too hard
          loremisafacrnaiucbyriuabxiuayrxub askljkdsjkfkjafds
          siiasdfidsafisdfahj
          jhdsfiodsfiho
